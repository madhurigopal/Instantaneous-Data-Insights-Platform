## Change Data size

change the number in the line with console.log

## Run
This will overwrite the `data-out.json` file, so change it if you care
You also need nodejs
```
node index.js > data-out.json
```
